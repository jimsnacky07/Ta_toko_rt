<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Pesanan extends Model
{
    use HasFactory;

    protected $table = 'pesanan'; // kamu memang pakai singular
    protected $fillable = ['user_id','order_date','status','total_harga'];
    protected $casts   = ['order_date' => 'date'];

    // --- Relasi utama ---
    // 1 pesanan dimiliki oleh 1 user (pemesan)
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    // 1 pesanan punya banyak detail (item)
    public function detailPesanan()
    {
        return $this->hasMany(DetailPesanan::class, 'pesanan_id', 'id');
    }

    // Alias biar bisa dipanggil $pesanan->details
    public function details()
    {
        return $this->detailPesanan();
    }

    // --- Relasi pendukung sesuai ERD ---
    // 1 pesanan punya banyak pembayaran
    public function pembayarans()
    {
        return $this->hasMany(Pembayaran::class, 'pesanan_id', 'id');
    }

    // 1 pesanan punya 1 data ukuran badan
    public function ukuran()
    {
        return $this->hasOne(DataUkuranBadan::class, 'pesanan_id', 'id');
    }

    // 1 pesanan punya 1 customer request
    public function customerRequest()
    {
        return $this->hasOne(CustomerRequest::class, 'pesanan_id', 'id');
    }

    // Produk yang dipesan (via tabel detail_pesanan sebagai pivot beratribut)
    public function products()
    {
        return $this->belongsToMany(Product::class, 'detail_pesanan', 'pesanan_id', 'product_id')
                    ->withPivot(['jumlah','harga_satuan','total_harga'])
                    ->withTimestamps();
    }

    // Status yang disarankan
    public const STATUSES = ['menunggu','diproses','siap-diambil','selesai','dibatalkan'];
}
