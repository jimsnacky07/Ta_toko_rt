<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    use HasFactory;

    // Nama tabel (opsional, kalau sama dengan plural dari nama model bisa di-skip)
    protected $table = 'order_items';

    // Kolom yang bisa diisi mass-assignment
    protected $fillable = [
        'order_id',
        'sku',
        'name',
        'price',
        'qty',
        'line_total',
        'product_id',
    ];

    /**
     * Relasi ke model Order
     * Satu item hanya punya satu order
     */
    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    /**
     * Relasi ke model Product (opsional, jika ada tabel products)
     */
    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function orderItems()
    {
        return $this->hasMany(OrderItem::class, 'order_id', 'id');
    }
}
