<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $table = 'orders';

    protected $fillable = [
        // Kolom yang ada di model kamu
        'user_id','order_code','queue_date','queue_no','status',
        'gross_amount','notes',

        // Kolom tambahan yang saya tambahkan
        'order_id','title','description',
        'order_type','garment_type','fabric_type','measurements','request_note','images','ordered_at',
        'tailor_id','admin_note','tailor_note','amount','production_status','paid_at',
    ];

    protected $casts = [
        // Kolom yang ada di model kamu
        'queue_date'   => 'date',
        'gross_amount' => 'integer',

        // Kolom tambahan yang saya tambahkan
        'measurements' => 'array',
        'images'       => 'array',
        'ordered_at'   => 'datetime',
    ];

    /** Relasi ke user (customer) */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /** Relasi ke tailor (penjahit) */
    public function tailor()
    {
        return $this->belongsTo(Tailor::class);
    }

    /** Relasi pembayaran (satu pembayaran utama) */
    public function pembayaran()
    {
        return $this->hasOne(Pembayaran::class, 'order_id', 'id');
    }

    /** Relasi pembayaran (banyak pembayaran/riwayat) */
    public function pembayarans()
    {
        return $this->hasMany(Pembayaran::class, 'order_id', 'id');
    }

    /** Relasi ke order_items */
    public function orderItems()
    {
        return $this->hasMany(OrderItem::class, 'order_id', 'id');
    }

    /** Relasi ke detail_pesanan (atau detailpesanan sesuai tabelmu) */
    public function detailPesanan()
    {
        return $this->hasMany(DetailPesanan::class, 'order_id', 'id');
    }

    /** Relasi ke histories (riwayat status) */
    public function histories()
    {
        return $this->hasMany(OrderHistory::class, 'order_id', 'id');
    }

    public function payment()
    {
        return $this->belongsTo(Payment::class);
    }

    // === Helper status ===
    public const STATUS_MENUNGGU          = 'menunggu_giliran';
    public const STATUS_SEDANG_DIKERJAKAN = 'sedang_dikerjakan';
    public const STATUS_SELESAI_DIKERJAKAN= 'selesai_dikerjakan';
    public const STATUS_SIAP_DIJEMPUT     = 'siap_dijemput';

    public function setStatusMenungguGiliran()   { $this->update(['status'=>self::STATUS_MENUNGGU]); }
    public function setStatusSedangDikerjakan()  { $this->update(['status'=>self::STATUS_SEDANG_DIKERJAKAN]); }
    public function setStatusSelesaiDikerjakan() { $this->update(['status'=>self::STATUS_SELESAI_DIKERJAKAN]); }
    public function setStatusSiapDijemput()      { $this->update(['status'=>self::STATUS_SIAP_DIJEMPUT]); }

    // === Helper function untuk menghitung amount ===

    // Fungsi untuk menghitung total harga pesanan
    public function calculateAmount()
    {
        $total = 0;

        foreach ($this->orderItems as $item) {
            // Menghitung harga berdasarkan quantity dan price
            $total += $item->quantity * $item->price;
        }

        return $total;
    }

    // Fungsi untuk mendapatkan jenis pakaian dari item pesanan
    public function getGarmentType()
    {
        $item = $this->orderItems()->first(); // Ambil item pertama (sesuaikan dengan logika)

        return $item ? $item->garment_type : null; // Mengambil jenis pakaian dari produk
    }

    // Set amount dan garment_type secara otomatis setelah pembayaran berhasil
    public function updateOrderAfterPayment()
    {
        // Update amount jika belum ada
        if (!$this->amount) {
            $this->amount = $this->calculateAmount();
        }

        // Update garment_type jika belum ada
        if (!$this->garment_type) {
            $this->garment_type = $this->getGarmentType();
        }

        // Simpan perubahan
        $this->save();
    }
}
