<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Order;
use App\Models\OrderItem;        // optional: jika pakai tabel order_items
use App\Models\DetailPesanan;    // optional: jika pakai detail_pesanan
use App\Models\Pembayaran;       // optional: jika menyimpan snap_token di tabel pembayaran
use Midtrans\Config as MidtransConfig;
use Midtrans\Snap;

class OrderController extends Controller
{
    /**
     * Pusat pesanan user (list).
     * Mengirim $orders ke view user/pesanan/pusat_pesanan.blade.php
     */
    public function index(Request $request)
    {
        $q      = $request->input('q');
        $status = $request->input('status');
        $tab    = $request->input('tab', 'all');

        $orders = Order::with(['user','payment','tailor'])
            ->where('user_id', Auth::id()) // hanya pesanan milik user login
            ->when($q, function ($query) use ($q) {
                // Bungkus di where(...) agar orWhere tidak menembus filter user_id
                $query->where(function ($s) use ($q) {
                    $s->whereHas('user', function ($u) use ($q) {
                            $u->where('name', 'like', "%{$q}%")
                              ->orWhere('email', 'like', "%{$q}%");
                        })
                      ->orWhere('id', $q)
                      ->orWhere('order_id', 'like', "%{$q}%")
                      ->orWhere('order_code', 'like', "%{$q}%")
                      ->orWhereDate('created_at', $q);
                });
            })
            ->when($status, fn($query) => $query->where('status', $status))
            ->latest()
            ->paginate(20)
            ->withQueryString();

        return view('user.pesanan.pusat_pesanan', compact('orders','q','status','tab'));
    }

    /**
     * [OPSIONAL] Step sebelum konfirmasi: hitung harga & simpan ke session.
     */
    public function review(Request $r)
    {
        $jenisPakaian = $r->input('jenis_pakaian');
        $jenisKain    = $r->input('jenis_kain');
        $qty          = max((int)$r->input('jumlah', 1), 1);
        $pickup       = $r->input('pickup');
        $catatan      = $r->input('request');

        // TODO: ganti sesuai logika/DB kamu
        $base = $this->priceForCloth($jenisPakaian);
        $add  = $this->fabricAdd($jenisKain);

        $unitTotal = $base + $add;
        $grand     = $unitTotal * $qty;

        $data = $r->all() + [
            'base_price'  => $base,
            'fabric_add'  => $add,
            'total_price' => $unitTotal,
            'grand_total' => $grand,
            'jumlah'      => $qty,
            'pickup'      => $pickup,
            'request'     => $catatan,
        ];

        session(['checkout' => $data]);

        return redirect()->route('konfirmasi.pesanan');
    }

    /**
     * [OPSIONAL] Halaman konfirmasi: ambil angka dari session agar konsisten.
     */
    public function konfirmasi(Request $r)
    {
        $payload = session('checkout') ?? $r->all();

        if (!isset($payload['base_price'])) {
            $qty  = max((int)($payload['jumlah'] ?? 1), 1);
            $base = $this->priceForCloth($payload['jenis_pakaian'] ?? null) ?? 0;
            $add  = $this->fabricAdd($payload['jenis_kain'] ?? null) ?? 0;

            $payload['base_price']  = $base;
            $payload['fabric_add']  = $add;
            $payload['total_price'] = $base + $add;
            $payload['grand_total'] = ($base + $add) * $qty;
            $payload['jumlah']      = $qty;

            session(['checkout' => $payload]);
        }

        return view('user.konfirmasi', ['data' => $payload]);
    }

    /**
     * Buat order (pending) lalu alihkan ke show() untuk Snap token.
     */
    public function pembayaran(Request $r)
    {
        $data = session('checkout');
        abort_unless($data, 400, 'Data checkout tidak ditemukan');

        // jika sudah pernah buat order, langsung ke show
        if ($orderId = session('order_id')) {
            if ($existing = Order::where('user_id', Auth::id())->find($orderId)) {
                return redirect()->route('user.orders.show', $existing);
            }
        }

        $order = new Order();
        $order->user_id      = Auth::id();
        $order->status       = 'pending';                            // status bayar (versimu)
        $order->gross_amount = (int)($data['grand_total'] ?? 0);     // jumlah total rupiah
        $order->notes        = $data['request'] ?? null;
        // tambahkan kolom lain kalau dibutuhkan (title/description/dll)
        $order->save();

        // Simpan 1 line item ke salah satu tabel detail yang kamu punya
        if (class_exists(OrderItem::class) && method_exists($order, 'orderItems')) {
            $order->orderItems()->create([
                'product_id' => $data['product_id'] ?? null,
                'name'       => $data['jenis_pakaian'] ?? 'Custom Item',
                'price'      => (int)($data['total_price'] ?? 0),
                'quantity'   => (int)($data['jumlah'] ?? 1),
            ]);
        } elseif (class_exists(DetailPesanan::class) && method_exists($order, 'detailPesanan')) {
            $order->detailPesanan()->create([
                'product_id' => $data['product_id'] ?? null,
                'name'       => $data['jenis_pakaian'] ?? 'Custom Item',
                'price'      => (int)($data['total_price'] ?? 0),
                'quantity'   => (int)($data['jumlah'] ?? 1),
            ]);
        }

        session(['order_id' => $order->id]);

        return redirect()->route('user.orders.show', $order);
    }

    /**
     * Halaman pembayaran + generate Snap Token Midtrans.
     * NOTE: route model binding + proteksi kepemilikan.
     */
    public function show(Order $order)
    {
        // Pastikan user yang login memang pemilik order
        abort_if($order->user_id !== Auth::id(), 403);

        // Reuse snap_token jika kamu simpan di tabel pembayaran
        $payment = method_exists($order, 'pembayarans')
            ? $order->pembayarans()->latest()->first()
            : null;

        $snap_token = $payment->snap_token ?? '';

        if (!$snap_token) {
            // Konfig Midtrans: ambil dari services.midtrans.* atau fallback midtrans.*
            MidtransConfig::$serverKey    = config('services.midtrans.server_key', config('midtrans.server_key'));
            MidtransConfig::$isProduction = (bool) config('services.midtrans.is_production', config('midtrans.is_production', false));
            MidtransConfig::$isSanitized  = true;
            MidtransConfig::$is3ds        = true;

            // Detail transaksi
            $transaction_details = [
                'order_id'     => $order->id,                  // atau $order->order_id kalau ada
                'gross_amount' => (int)$order->gross_amount,
            ];

            // Detail customer
            $u = $order->user;
            $customer_details = [
                'first_name' => $u->name  ?? 'Customer',
                'last_name'  => '',
                'email'      => $u->email ?? null,
                'phone'      => $u->phone ?? null,
            ];

            // Kumpulkan item dari relasi; fallback 1 item jika kosong
            $item_details = [];

            if (method_exists($order, 'orderItems') && ($order->relationLoaded('orderItems') ? $order->orderItems->count() : $order->orderItems()->exists())) {
                foreach ($order->orderItems as $it) {
                    $item_details[] = [
                        'id'       => $it->product_id ?? $it->id,
                        'price'    => (int)$it->price,
                        'quantity' => (int)$it->quantity,
                        'name'     => $it->name ?? 'Item',
                    ];
                }
            } elseif (method_exists($order, 'detailPesanan') && ($order->relationLoaded('detailPesanan') ? $order->detailPesanan->count() : $order->detailPesanan()->exists())) {
                foreach ($order->detailPesanan as $dp) {
                    $item_details[] = [
                        'id'       => $dp->product_id ?? $dp->id,
                        'price'    => (int)$dp->price,
                        'quantity' => (int)$dp->quantity,
                        'name'     => $dp->name ?? 'Item',
                    ];
                }
            }

            if (empty($item_details)) {
                $item_details[] = [
                    'id'       => $order->id,
                    'price'    => (int)$order->gross_amount,
                    'quantity' => 1,
                    'name'     => 'Order #'.$order->id,
                ];
            }

            $transaction = [
                'transaction_details' => $transaction_details,
                'customer_details'    => $customer_details,
                'item_details'        => $item_details,
                'callbacks'           => [
                    'finish'   => route('midtrans.finish'),
                    'unfinish' => route('midtrans.unfinish'),
                    'error'    => route('midtrans.error'),
                ],
            ];

            try {
                $snap_token = Snap::getSnapToken($transaction);

                // opsional: simpan snap_token ke tabel pembayaran jika kamu pakai itu
                if ($payment instanceof Pembayaran) {
                    $payment->snap_token = $snap_token;
                    $payment->save();
                }
            } catch (\Throwable $e) {
                report($e);
                $snap_token = ''; // biar view bisa handle gracefully
            }
        }

        // ganti 'user.pesanan.show' sesuai view detail kamu
        return view('user.pesanan.show', compact('order', 'snap_token'));
    }

    /**
     * [OPSIONAL] Simpan pesanan dari halaman konfirmasi.
     */
   public function simpan(Request $request)
{
    return redirect()->route('oc.konfirmasi', ['test' => 1] + $request->all());
    // Jangan terlalu ketat dulu, biar gak 422
    $data = $request->validate([
        'jenis_pakaian'            => 'required|string',
        'jenis_kain'               => 'required|string',
        'jenis_ukuran'             => 'required|string',
        'jumlah'                   => 'nullable|integer|min:1',
        'pickup'                   => 'nullable|string',
        'request'                  => 'nullable|string',
        'kain_aksesoris_customer'  => 'nullable|in:0,1',
        'gambar_custom'            => 'nullable|image|max:2048',
    ]);

    // Default aman
    $data['jumlah']  = max(1, (int)($data['jumlah'] ?? 1));
    $data['pickup']  = $data['pickup'] ?? 'jemput_toko';
    $data['request'] = $data['request'] ?? '-';
    $data['kain_aksesoris_customer'] = (int)($data['kain_aksesoris_customer'] ?? 0);

    // Simpan file jika ada (optional)
    if ($request->hasFile('gambar_custom')) {
        $data['gambar_path'] = $request->file('gambar_custom')->store('pesanan', 'public');
    }

    // Redirect ke halaman konfirmasi + bawa data via query string
    return redirect()->route('oc.konfirmasi', $data);
}

    /**
     * (Opsional) Alternatif daftar pesanan user.
     */
    public function myOrders(Request $r)
    {
        $orders = Order::with(['payment', 'pembayarans', 'tailor'])
            ->where('user_id', $r->user()->id)
            ->latest()
            ->paginate(20)
            ->withQueryString();

        // kalau mau tetap pakai view ini, silakan
        return view('user.pesanan.pusat_pesanan', compact('orders'));
    }

    // ====== Helper harga contoh (ganti sesuai data kamu) ======
    private function priceForCloth(?string $jenis): int
    {
        return match ($jenis) {
            'jas' => 120000,
            default => 0,
        };
    }

    private function fabricAdd(?string $kain): int
    {
        return match ($kain) {
            'katun' => 0,
            default => 0,
        };
    }

    public function store(Request $request)
{
    // Validasi data yang dimasukkan
    $request->validate([
        'user_id' => 'required|exists:users,id',
        'product_id' => 'required|exists:products,id',
    ]);

    // Ambil data produk berdasarkan product_id
    $product = Product::find($request->product_id);

    // Debugging untuk memeriksa produk yang diambil
    dd($product);  // Pastikan produk ditemukan

    // Tentukan garment_type berdasarkan kategori produk
    $garmentType = $product->category ?? 'Kategori tidak ditemukan';

    // Membuat data pesanan baru
    $order = Order::create([
        'user_id' => $request->user_id,
        'order_code' => strtoupper(uniqid('ORDER')),
        'garment_type' => $garmentType,  // Mengisi garment_type berdasarkan kategori produk
        'status' => 'PENDING',
        'created_at' => now(),
        'updated_at' => now(),
    ]);

    // Lakukan operasi lain jika perlu, seperti menambahkan item ke pesanan
    return redirect()->route('user.orders.index')->with('success', 'Pesanan berhasil dibuat.');
}


}
