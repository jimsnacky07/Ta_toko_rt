<!DOCTYPE html>
<html>
<head>
    <title>Romansa Tailor</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
    <div class="container mx-auto mt-10">
        <h1 class="text-3xl font-bold">Selamat datang di Romansa Tailor</h1>
        <p>Pesan jahitan dengan mudah dan cepat.</p>
    </div>

   Chat Sekarang
</a>

</body>
</html>
